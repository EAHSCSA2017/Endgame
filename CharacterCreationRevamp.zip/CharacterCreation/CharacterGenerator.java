import java.util.*;
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CharacterGenerator
{
    static String g = "";
    static String f = "";
    static String l = "";
    public static void CharacterGenerator(){
        System.out.println(MakeName());
        System.out.print('\u000C');
        
        Traits[] traits = Traits.Create();
        Skill[] skills = Skill.Create();
    }
    //asks and assigns first last and gender
    public static String MakeName(){
        System.out.println("What's your gender?");
        g = UserInput.getString();
        System.out.println("What's your first name?");
        f = UserInput.getString();
        System.out.println("What's your last name?");
        l = UserInput.getString();
        Names name = new Names(f, l, g);
        return "Your name is " + f + " " + l + ". You are a " + g;  
    }

}
