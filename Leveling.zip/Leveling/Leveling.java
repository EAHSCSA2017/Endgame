
/**
 * Write a description of class Leveling here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Leveling
{
    static int XP = 0;
    static int level = 0;

    public Leveling(){
        int XP;
    }

    public Leveling(int XP){
        this.XP=XP;
    }

    public static int getXP(){
        return XP;
    }

    public static void setXP(int X){
        XP = X;
    }

    public static void levelUp(){
        stamina+=5;
        mana+=5;
        health+=10;
        strength+=5;        
    }

    public static void Levels(){  
        int level1 = 10; 
        int level2 = 20;
        int level3 = 40;
        int level4 = 80;
        int level5 = 160;
        int level6 = 320;
        int level7 = 640;
        int level8 = 1280;
        int level9 = 2560;
        int level10 = 5120;

        if(XP == level1){
            Leveling.levelUp();
            level=1;
            System.out.println("You have leveled up!");
        }
        if(XP == level2){
            Leveling.levelUp();
            level=2;
            System.out.println("You have leveled up!");
        }
        if(XP == level3){
            Leveling.levelUp();
            level=3;
            System.out.println("You have leveled up!");
        }
        if(XP == level4){
            Leveling.levelUp();
            level=4;
            System.out.println("You have leveled up!");
        }
        if(XP == level5){
            Leveling.levelUp();
            level=5;
            System.out.println("You have leveled up!");
        }
        if(XP == level6){
            Leveling.levelUp();
            level=6;
            System.out.println("You have leveled up!");
        }
        if(XP == level7){
            Leveling.levelUp();
            level=7;
            System.out.println("You have leveled up!");
        }
        if(XP == level8){
            Leveling.levelUp();
            level=8;
            System.out.println("You have leveled up!");
        }
        if(XP == level9){
            Leveling.levelUp();
            level=9;
            System.out.println("You have leveled up!");
        }
        if(XP == level10){
            Leveling.levelUp();
            level=10;
            System.out.println("You have leveled up!");
        }
    }
}
