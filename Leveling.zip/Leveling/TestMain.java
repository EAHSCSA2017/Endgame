
/**
 * Write a description of class TestMain here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestMain extends Leveling
{
  public static void main(){
      int end=1;
      System.out.println("Test ready to start");
      System.out.println("Current XP: " + XP);
      while(end==1){
          String choice = UserInput.getString();
          choice = choice.toUpperCase();          
          if(choice.equals("END")){
              end=0;
              break;
            }
          switch (choice){
              case "U":
              XP+=10;
              System.out.println("Current XP: " + XP);
              Leveling.Levels();
              System.out.println("Your current level is: " + level);
              break;
            }
      }
  }
}
