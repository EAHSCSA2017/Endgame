
/**
 * Write a description of class Names here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Names extends Character
{
    String fName = "";
    String lName = "";
    String nName = "";
    String gender = "";
    public Names(){
        fName = "";
        lName = "";
        gender = "";
    }

    public Names(String f, String l, String g){
        this.fName = f;
        this.lName = l;
        this.gender = g;
    }

    public String getFName(){
        return fName;
    }

    public String getGender(){
        return gender;
    }

    //     public static Names[] Create(){
    // 
    //         Names Bill = new Names("Bill" , "Male");
    //         Names Jeffery = new Names("Jeffery" , "Male");
    //         Names AAyan = new Names("AAyan" , "Male");
    //         Names Garth = new Names("Garth" , "Male");
    //         Names Micheal = new Names("Micheal" , "Male");
    //         Names George = new Names("George" , "Male");
    //         Names Phillip = new Names("Phillip" , "Male");
    //         Names Jorjey = new Names("Jorjey" , "Male");
    //         Names Jose = new Names("Jose" , "Male");
    //         Names Juan = new Names("Juan" , "Male");
    //         Names Lukas = new Names("Lukas" , "Male");
    //         Names Anakin = new Names("Anakin" , "Male");
    //         Names Connor = new Names("Connor" , "Male");
    //         Names Nathaniel = new Names("Nathaniel" , "Male");
    //         Names Nickolas = new Names("Nickolas" , "Male");
    //         Names Xachariah = new Names("Xachariah" , "Male");
    //         Names Jebodia = new Names("Jebodia" , "Male");
    //         Names Donald = new Names("Donald" , "Male");
    //         Names Brock = new Names("Brock" , "Male");
    //         Names Craig = new Names("Craig" , "Male");
    //         Names Adam = new Names("Adam" , "Male");
    //         Names Seth = new Names("Seth" , "Female");
    //         Names Jeremy = new Names("Jeremy" , "Male");
    //         Names Miguel = new Names("Miguel" , "Male");
    //         Names Jennifer = new Names("Jennifer" , "Female");
    //         Names Stephanie = new Names("Stephanie" , "Female");
    //         Names Susan = new Names("Susan" , "Female");
    //         Names Juanita = new Names("Juanita" , "Female");
    //         Names Shakire = new Names("Shakire" , "Female");
    //         Names Patricia = new Names("Patricia" , "Female");
    //         Names Cheyanna = new Names("Cheyanna" , "Female");
    //         Names Shequada = new Names("Shequada" , "Female");
    //         Names Jessica = new Names("Jessica" , "Female");
    //         Names Tiffany = new Names("Tiffany" , "Female");
    //         Names Sharkiesha = new Names("Sharkiesha" , "Female");
    //         Names Tila = new Names("Tila" , "Female");
    //         Names Emma = new Names("Emma" , "Female");
    //         Names Natalie = new Names("Natalie" , "Female");
    //         Names Olivia = new Names("Olivia" , "Female");
    //         Names Sophia = new Names("Sophia" , "Female");
    //         Names Shaniqua = new Names("Shaniqua" , "Female");
    //         Names Isabella = new Names("Isabella" , "Female");
    //         Names Mia = new Names("Mia" , "Female");
    //         Names Abigail = new Names("Abigail" , "Female");
    //         Names Emily = new Names("Emily" , "Female");
    //         Names Nora = new Names("Nora" , "Female");
    //         Names Skyler = new Names("Skyler" , "Female");
    //         Names[] first = new Names[]{ Bill , Jeffery , AAyan , Garth , Micheal , George , Phillip , Jorjey , Jose , Juan ,  Lukas , Anakin , Connor , Nathaniel , Nickolas , Xachariah ,  Jebodia ,  Donald ,  Brock ,  Craig ,  Adam ,  Jeremy ,  Seth ,  Miguel , Jennifer , Stephanie , Susan , Juanita , Shakire , Patricia , Cheyanna ,  Shequada , Jessica , Tiffany , Sharkiesha , Tila , Emma , Natalie , Olivia , Sophia , Shaniqua , Isabella , Mia , Abigail , Emily , Nora , Skyler};
    //         
    //         return first;
    //     }
}
