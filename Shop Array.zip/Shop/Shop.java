import java.util.ArrayList;
/**
 * Write a description of class Shop here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shop
{
    String name = "";
    String desc = "";
    int index = 0;
    public Shop(){
        name = "";
        desc = "";
        index = 0;
    }

    public Shop(String name, String desc, int index){
        this.name=name;
        this.desc=desc;
        this.index=index;
    }

    public String getShopName(){
        return name;
    }

    public String getShopDesc(){
        return desc;
    }
     //   Shop melee = new Shop("name","desc",0);
    public static void Create(){
        Shop[] town=new Shop[4];
        town[0]=new Shop("Weapons","Buy some guns.",0);
        town[1]=new Shop("Armor","Buy some pants.",1);
        town[2]=new Shop("Potions","Buy some drank.",2);
    }

}