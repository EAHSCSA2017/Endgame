
/**
 * Write a description of class traits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Traits extends Character
{
    String name;
    int skillaff;
    int skillamt;
    public Traits(String n, int aff, int amt){
        this.name = n;
        this.skillaff = aff;
        this.skillamt = amt;
    }
    public String getName(){
        return name;
    }
    public int getSkillaff(){
        return skillaff;
    }
    public int getSkillamt(){
        return skillamt;
    }
    public static Traits[] Create(){
        Traits trait1 = new Traits("can play guitar", 8, 4);
        Traits trait2 = new Traits("can speak every language", 9, 7);
        Traits trait3 = new Traits("can do a handstand", 10, 2);
        Traits trait4 = new Traits("can breathe underwater", 7, 5);
        Traits trait5 = new Traits("knows how to knit", 3, 4);
        Traits trait6 = new Traits("Global Elite on CS:GO", 1, 4);
        Traits trait7 = new Traits("Silver 1 on CS:GO", 1, 2);
        Traits trait8 = new Traits("Can play LOL without throwing up", 5, 1);
        Traits trait9 = new Traits("Can do a backflip", 1, 2);
        Traits trait10 = new Traits("Has a strong arm", 6, 3);
        Traits trait11 = new Traits("Can fold a Domino's pizza box in .8 seconds", 2, 3);
        Traits trait12 = new Traits("can Drive with their feet", 10, 3);
        Traits trait13 = new Traits("Knows Karate", 1, 3);
        Traits trait14 = new Traits("Can make a mean burger", 2, 5);
        Traits trait15 = new Traits("Is a vegan", 5, 5);
        Traits trait16 = new Traits("Can moon walk", 9, 2);
        Traits trait17 = new Traits("Drinks too much water", 7, 1);
        Traits trait18 = new Traits("Hates Roller Coasters", 8, 0);
        Traits trait19 = new Traits("Loves Roller Coasters", 8, 1);
        Traits trait20 = new Traits("Playes a trumpet", 8, 9);
        Traits[] traits = new Traits[]{trait1, trait2,trait3,trait4,trait5,trait6,trait7,trait8,trait9,trait10,trait11,trait12,trait13,trait14,trait15,trait16,trait17,trait18,trait19,trait20};
        return traits;
    }
}
