
/**
 * Write a description of class skill here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Skill extends Character
{
    int level;
    String name;
    int index;
    public Skill(){
        name = "";
        level = 0;
        index = 0;
    }

    public Skill(String n){
        this.name = n;
        level = 0;
        index = 0;
    }

    public Skill(String n, int l){
        this.name = n;
        this.level = l;
        index = 0;
    }

    public Skill(String n, int l, int i){
        this.name = n;
        this.level = l;
        this.index = i;
    }

    public String getName(){
        return name;
    }

    public int getLevel(){
        return level;
    }

    public int getIndex(){
        return index;
    }

    public void setName(String n){
        name = n;
    }

    public void setLevel(int l){
        level = l;
    }

    public void setIndex(int i){
        index = i;
    }

    static int skillPoints=20;
    public static Skill[] Create(){
        Skill stamina = new Skill("Stamina", 0, 1);
        Skill mana = new Skill("Mana    ", 0, 2);
        Skill majika = new Skill("Majika", 0, 3);
        Skill health = new Skill("Health", 0, 4);
        Skill strength = new Skill("Strength", 0, 5);
        Skill penor = new Skill("Dick Size", 0, 6);
        Skill[] skills = new Skill[]{stamina, mana, majika, health, strength, penor};

        for(int z=0;z<skills.length;z++){
            System.out.println("("+skills[z].getIndex()+")"+skills[z].getName() + "\t" + skills[z].getLevel());
        }

        while(skillPoints>0){
            System.out.println("You have " + skillPoints + " skill points." + "\n" + "Enter the number of the skill you want to add a point to.");
            System.out.println("");
            int n = Integer.parseInt(UserInput.getString());
            System.out.print('\u000C');
            for(int x=0; x<skills.length;x++){
                if(n == skills[x].getIndex()){
                    changeSkill(skills[x],1);
                }
            }
            skillPoints--;
            for(int z=0;z<skills.length;z++){
                System.out.println("("+skills[z].getIndex()+")"+skills[z].getName() + "\t" + skills[z].getLevel());
            }
        }
        return skills;
    }
    //type in skill, and amount to add
    public static void changeSkill(Skill s, int a){
        s.setLevel(s.getLevel()+a);
    }
}

