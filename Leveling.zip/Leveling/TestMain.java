
/**
 * Write a description of class TestMain here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestMain extends Leveling
{
  public static void main(){
      int end=1;
      System.out.println("Test ready to start");
      System.out.println("Current XP: " + XP);
      while(end==1){
          String choice = UserInput.getString();
          choice = choice.toUpperCase();          
          if(choice.equals("END")){
              end=0;
              break;
            }
          switch (choice){
              case "U":
              XP+=10; // adds 10 xp every time
              System.out.println("Current XP: " + XP);
              Leveling.Levels(); // This currently has to run the method every
                                 // time I select u, could probably use a
                                 // better way to do this.
              System.out.println("Your current level is: " + level);
              System.out.println(" ");
              System.out.println("Stats");
              System.out.println("Majika ="+majika);
              System.out.println("Stamina ="+stamina);
              System.out.println("Mana ="+mana);
              System.out.println("Health ="+health);
              System.out.println("Strength ="+strength);
              System.out.println("Penor size ="+penorSize);
              System.out.println(" ");
              break;
            }
      }
  }
}
