
/**
 * Write a description of class Abstract here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Character {
    String name;
    public String getName(){
        return name;
    } 
}
