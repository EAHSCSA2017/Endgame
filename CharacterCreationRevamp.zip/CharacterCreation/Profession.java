
/**
 * Write a description of class Profession here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Profession extends Character
{
    String name;
    int skillaff;
    int skillamt;
    public Profession(String n, int aff, int amt){
        this.name = n;
        this.skillaff = aff;
        this.skillamt = amt;
    }

    public String getName(){
        return name;
    }

    public int getSkillaff(){
        return skillaff;
    }

    public int getSkillamt(){
        return skillamt;
    }
    public static Profession[] Create(){
        Profession doctor = new Profession("Doctors", 4, 5);
        Profession lumberjack = new Profession("Lumberjack", 6, 3);
        Profession horse = new Profession("Horse", 7, 10);
        Profession soldier = new Profession("Soldier", 1, 6);
        Profession bitcoinTrader = new Profession("Bitcoin Trader", 6, 2);
        Profession plumber = new Profession("Plumber", 4, 3);
        Profession plumber1 = new Profession("Plumber ;)", 10, 3);
        Profession landlord = new Profession("Landlord", 10, 6);
        Profession knight = new Profession("Knight", 1, 4);
        Profession professionalCartwheeler = new Profession("Professional Cartwheeler", 9, 3);
        Profession scientist = new Profession("Scientist", 4, 5);
        Profession bodyGaurd = new Profession("Body Gaurd", 1, 3);
        Profession mathematician = new Profession("Methematician", 3, 1);
        Profession competitiveEater = new Profession("Competitive Eater", 2, 4);
        Profession teacher = new Profession("Teacher", 9, 3);
        Profession tailor = new Profession("Tailor", 3, 6);
        Profession cobbler = new Profession("Cobbler", 3, 4);
        Profession electrician = new Profession("Electrician", 4, 2);
        Profession professionalProfessional = new Profession("Professional Professional", 1, 0);
        Profession farmer = new Profession("Farmer", 5, 5);
        Profession[] professions = new Profession[]{doctor,lumberjack,horse,soldier,bitcoinTrader,plumber,plumber1,landlord,knight,professionalCartwheeler,scientist,farmer, professionalProfessional, bodyGaurd,mathematician,competitiveEater,teacher,tailor,cobbler,electrician};
        return professions;
    }
}
