
/**
 * Write a description of class skill here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Skill extends Character
{
    int level;
    String name;
    public Skill(){
        name = "";
        level = 0;
    }
    public Skill(String n){
        this.name = n;
        level = 0;
    }
    public Skill(String n, int l){
        this.name = n;
        this.level = l;
    }
    public String getName(){
        return name;
    }
    public int getLevel(){
        return level;
    }
    public void setName(String n){
        name = n;
    }
    public void setLevel(int l){
        level = l;
    }
    public static Skill[] Create(){
        Skill stamina = new Skill("Stamina", 4);
        Skill mana = new Skill("Mana", 4);
        Skill majika = new Skill("Majika", 4);
        Skill health = new Skill("Health", 4);
        Skill strength = new Skill("Strength", 4);
        Skill penor = new Skill("Dick Size", 4);
        Skill[] skills = new Skill[]{stamina, mana, majika, health, strength, penor};
        return skills;
    }
    //type in skill, and amount to add
    public static void changeSkill(Skill s, int a){
        s.setLevel(s.getLevel()+a);
    }
}
