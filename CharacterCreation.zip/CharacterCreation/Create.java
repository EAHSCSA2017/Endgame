
/**
 * Write a description of class Create here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Create
{
    
      Character[] Create();
}
