import java.util.*;
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CharacterGenerator
{
    static String g = "";
    static String f = "";
    static String l = "";
    public static void CharacterGenerator(){
        String[] health = new String[]{"Recent Concussion", "Broken Nose", "Eye Patch", "Blind", "Seductive voice", "Clubfoot", "11 toes", "amputee", "missing two toes", "open wound", "looks good in shorts", "Super swoll right arm ;)", "dainty fingers", "infection", "6 fingers", "no thumbs", "missing bicep", "no belly button", "looks like Iggy Pop", "missing nipples", "missing Kidney", "lack of a heart", "Strong bones"};
        Traits[] traits = Traits.Create();
        Skill[] skills = Skill.Create();
        Profession[] professions = Profession.Create();

        System.out.println("Your character's name is: ");
        System.out.println(MakeName());
        System.out.println(chooseNick());
        System.out.println(chooseAge());
        System.out.println(chooseEducation());

        int p = (int)(Math.random()*professions.length);
        System.out.println("You used to be a: " + professions[p].getName());
        int t1 = (int)(Math.random()*(traits.length-1));
        int t2 = (int)(Math.random()*traits.length-1);
        System.out.println("Your special traits are: " +"\n"+"\t"+traits[t1].getName()+"\n"+"\t"+traits[t2].getName());
        int sl = (int)(Math.random()*4);
        // random skill boost
        for (int x=0; x<=sl;x++){
            int ps = (int)(Math.random()*skills.length);
            skills[ps].setLevel(skills[ps].getLevel()+(int)(Math.random()*7));
        }
        //traits affect skillz  
        int kkk = (skills[traits[t1].getSkillaff()-1].getLevel());
        int kk = (skills[traits[t2].getSkillaff()-1].getLevel());
        skills[(traits[t1].getSkillaff()-1)].setLevel(kkk+=traits[t1].getSkillamt());
        skills[(traits[t2].getSkillaff()-1)].setLevel(kkk+=traits[t2].getSkillamt());
        //profesions affect skillz        
        int prof = (skills[(professions[p].getSkillaff()-1)].getLevel());  
        skills[(professions[p].getSkillaff()-1)].setLevel(prof+=(traits[p].getSkillamt()));
        for (int t= 0; t<skills.length; t++){
            System.out.println( skills[t].getName()+":"+"\n"+"\t"+"\t"+"\t"+skills[t].getLevel());
        }
        
    }
    //asks and assigns first last and gender
    public static String MakeName(){
        System.out.println("What's your gender");
        g = UserInput.getString();
        System.out.println("What's your first name?");
        f = UserInput.getString();
        System.out.println("What's your last name?");
        l = UserInput.getString();
        Names name = new Names(f, l, g);
        return "Your name is " + f + " " + l + ". You are a " + g;  }

    public static String chooseNick(){
        String[] nick = new String[]{"Boop", "Bee-Bop","Angerey", "Babyface", "Noodle", "Monkey Wrench", "Glasses", "Shoog", "Knucklehead"};
        int nn= (int)(Math.random()*nick.length);
        return "Nickname: " +nick[nn];
    }
    
    public static String chooseAge(){
        int age = (int)(Math.random()*41)+20;
        return "Age: " + Integer.toString(age);
    }

    public static String chooseEducation(){
        String[] education = new String[]{"Middle School", "Highschool", "Tradeschool", "Home schooled", "Raised by Wolves", "Hogwarts", "Bachelors degree", "Associates degree", "Masters degree", "PHd"};       
        int e = (int)(Math.random()*education.length);
        return "They have a " + education[e] + " education";
    }

}
